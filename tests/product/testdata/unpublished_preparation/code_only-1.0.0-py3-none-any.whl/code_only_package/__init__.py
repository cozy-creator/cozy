import msgspec
from cozy_runtime.author import App, Config, Context, Loader, Model, uses_components
class Request(msgspec.Struct):
    prompt: str
class Result(msgspec.Struct):
    value: int
class Pipeline:
    def __init__(self, config: Config):
        import torch
        class Scalar(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.weight = torch.nn.Parameter(torch.empty(1, dtype=torch.float32))
        self.components = {"unet": Scalar()}
class Weights(Model[Pipeline]):
    def load(self, loader: Loader) -> None:
        self.pipe = loader.construct(Pipeline, factory=Pipeline)
    @uses_components("unet")
    def measure(self) -> int:
        raise AssertionError("model preparation cannot execute a handler")
app = App()
@app.entrypoint
def generate(ctx: Context, payload: Request, model: Weights) -> Result:
    raise AssertionError("code preparation cannot execute a handler")
